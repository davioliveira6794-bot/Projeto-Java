-- =====================================================
-- RecrutaTech — Script de Banco de Dados PostgreSQL
-- =====================================================

CREATE DATABASE recrutatech;
\c recrutatech;

-- O Hibernate cria as tabelas automaticamente com ddl-auto=update
-- Este script é para referência da modelagem

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id BIGSERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('ADMIN','RECRUTADOR','GESTOR')),
    criado_em TIMESTAMP DEFAULT NOW(),
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de vagas
CREATE TABLE IF NOT EXISTS vagas (
    id BIGSERIAL PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    descricao TEXT,
    area VARCHAR(100),
    nivel VARCHAR(50),
    modalidade VARCHAR(50),
    localizacao VARCHAR(255),
    salario NUMERIC(10,2),
    status VARCHAR(20) NOT NULL DEFAULT 'ABERTA' CHECK (status IN ('ABERTA','PAUSADA','ENCERRADA')),
    criado_por BIGINT REFERENCES usuarios(id),
    criada_em TIMESTAMP DEFAULT NOW(),
    encerrada_em TIMESTAMP
);

-- Requisitos das vagas (coleção)
CREATE TABLE IF NOT EXISTS vaga_requisitos (
    vaga_id BIGINT REFERENCES vagas(id) ON DELETE CASCADE,
    requisito VARCHAR(255)
);

-- Tabela de candidatos
CREATE TABLE IF NOT EXISTS candidatos (
    id BIGSERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    telefone VARCHAR(20),
    linkedin VARCHAR(255),
    github VARCHAR(255),
    cidade VARCHAR(100),
    estado VARCHAR(2),
    resumo TEXT,
    cadastrado_em TIMESTAMP DEFAULT NOW()
);

-- Habilidades dos candidatos (coleção)
CREATE TABLE IF NOT EXISTS candidato_habilidades (
    candidato_id BIGINT REFERENCES candidatos(id) ON DELETE CASCADE,
    habilidade VARCHAR(100)
);

-- Tabela de candidaturas (N:N entre candidatos e vagas)
CREATE TABLE IF NOT EXISTS candidaturas (
    id BIGSERIAL PRIMARY KEY,
    candidato_id BIGINT NOT NULL REFERENCES candidatos(id),
    vaga_id BIGINT NOT NULL REFERENCES vagas(id),
    status VARCHAR(30) NOT NULL DEFAULT 'INSCRITO'
        CHECK (status IN ('INSCRITO','TRIAGEM','ENTREVISTA','TECNICO','OFERTA','APROVADO','REPROVADO')),
    score_ia INTEGER CHECK (score_ia BETWEEN 0 AND 100),
    observacoes TEXT,
    inscrito_em TIMESTAMP DEFAULT NOW(),
    atualizado_em TIMESTAMP,
    UNIQUE(candidato_id, vaga_id)
);

-- Tabela de entrevistas
CREATE TABLE IF NOT EXISTS entrevistas (
    id BIGSERIAL PRIMARY KEY,
    candidatura_id BIGINT NOT NULL REFERENCES candidaturas(id),
    entrevistador_id BIGINT REFERENCES usuarios(id),
    data_hora TIMESTAMP NOT NULL,
    tipo VARCHAR(30) CHECK (tipo IN ('ONLINE','PRESENCIAL','TECNICA','COMPORTAMENTAL')),
    link_reuniao VARCHAR(500),
    nota INTEGER CHECK (nota BETWEEN 1 AND 10),
    feedback TEXT,
    realizada BOOLEAN DEFAULT FALSE
);

-- ── Dados de exemplo ───────────────────────────────

INSERT INTO usuarios (nome, email, senha, role) VALUES
    ('Ana Paula', 'ana@recrutatech.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh.2', 'ADMIN'),
    ('Carlos Mendes', 'carlos@recrutatech.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh.2', 'RECRUTADOR');
-- senha padrão: admin123 (bcrypt)

INSERT INTO vagas (titulo, area, nivel, modalidade, localizacao, status, criado_por) VALUES
    ('Dev Backend Sênior', 'Tecnologia', 'Sênior', 'Remoto', 'Brasil', 'ABERTA', 1),
    ('UX Designer', 'Design', 'Pleno', 'Híbrido', 'São Paulo', 'ABERTA', 1),
    ('Data Analyst', 'Dados', 'Pleno', 'Remoto', 'Brasil', 'ABERTA', 2);

INSERT INTO candidatos (nome, email, cidade, estado) VALUES
    ('Thiago Santos', 'thiago@email.com', 'São Paulo', 'SP'),
    ('Camila Rocha', 'camila@email.com', 'Rio de Janeiro', 'RJ'),
    ('Bruno Neves', 'bruno@email.com', 'Belo Horizonte', 'MG');

