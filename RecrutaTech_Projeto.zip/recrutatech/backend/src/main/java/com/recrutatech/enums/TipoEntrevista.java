package com.recrutatech.enums;
public enum TipoEntrevista { ONLINE, PRESENCIAL, TECNICA, COMPORTAMENTAL }
