package com.recrutatech.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Entidade Entrevista — agendamento de entrevistas com candidatos
 */
@Entity
@Table(name = "entrevistas")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Entrevista {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "candidato_id", nullable = false)
    private Candidato candidato;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vaga_id", nullable = false)
    private Vaga vaga;

    @Column(name = "data_hora", nullable = false)
    private LocalDateTime dataHora;

    @Enumerated(EnumType.STRING)
    private TipoEntrevista tipo;

    @Enumerated(EnumType.STRING)
    private StatusEntrevista status;

    @Column(length = 500)
    private String observacoes;

    @Column(name = "link_reuniao")
    private String linkReuniao;

    @Column(name = "criado_em")
    private LocalDateTime criadoEm;

    @PrePersist
    protected void onCreate() {
        criadoEm = LocalDateTime.now();
        if (status == null) status = StatusEntrevista.AGENDADA;
    }

    public enum TipoEntrevista {
        TRIAGEM, TECNICA, COMPORTAMENTAL, FINAL
    }

    public enum StatusEntrevista {
        AGENDADA, REALIZADA, CANCELADA, REAGENDADA
    }
}
