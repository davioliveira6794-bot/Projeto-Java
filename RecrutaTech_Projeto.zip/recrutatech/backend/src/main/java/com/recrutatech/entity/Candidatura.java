package com.recrutatech.entity;

import com.recrutatech.enums.StatusCandidatura;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name = "candidaturas")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Candidatura {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "candidato_id", nullable = false)
    private Candidato candidato;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vaga_id", nullable = false)
    private Vaga vaga;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusCandidatura status = StatusCandidatura.INSCRITO;

    private Integer scoreIA;          // 0–100 gerado pela IA de triagem

    @Column(columnDefinition = "TEXT")
    private String observacoes;

    @Column(updatable = false)
    private LocalDateTime inscritoEm = LocalDateTime.now();

    private LocalDateTime atualizadoEm;

    @PreUpdate
    public void preUpdate() {
        this.atualizadoEm = LocalDateTime.now();
    }
}
