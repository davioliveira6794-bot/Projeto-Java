package com.recrutatech.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Entidade Vaga — representa uma vaga de emprego
 */
@Entity
@Table(name = "vagas")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Vaga {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Título é obrigatório")
    @Size(max = 150)
    @Column(nullable = false)
    private String titulo;

    @Size(max = 1000)
    private String descricao;

    @Size(max = 100)
    private String departamento;

    @Size(max = 100)
    private String localizacao;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ModalidadeVaga modalidade;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusVaga status;

    @Column(name = "data_abertura")
    private LocalDate dataAbertura;

    @Column(name = "data_fechamento")
    private LocalDate dataFechamento;

    @Column(name = "criado_em")
    private LocalDateTime criadoEm;

    @OneToMany(mappedBy = "vaga", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Candidato> candidatos;

    @PrePersist
    protected void onCreate() {
        criadoEm = LocalDateTime.now();
        if (status == null) status = StatusVaga.ABERTA;
        if (dataAbertura == null) dataAbertura = LocalDate.now();
    }

    public enum StatusVaga {
        ABERTA, EM_SELECAO, ENCERRADA, PAUSADA
    }

    public enum ModalidadeVaga {
        PRESENCIAL, HIBRIDO, REMOTO
    }
}
