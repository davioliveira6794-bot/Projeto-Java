package com.recrutatech.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class AuthRequestDTO {
    @Email @NotBlank
    private String email;
    @NotBlank
    private String senha;
}
