package com.recrutatech.controller;

import com.recrutatech.dto.AuthRequestDTO;
import com.recrutatech.dto.AuthResponseDTO;
import com.recrutatech.entity.Usuario;
import com.recrutatech.repository.UsuarioRepository;
import com.recrutatech.security.JwtUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<AuthResponseDTO> login(@Valid @RequestBody AuthRequestDTO request) {
        Usuario usuario = usuarioRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Credenciais inválidas"));

        if (!passwordEncoder.matches(request.getSenha(), usuario.getSenha()))
            throw new RuntimeException("Credenciais inválidas");

        String token = jwtUtil.generateToken(usuario.getEmail(), usuario.getRole().name());
        return ResponseEntity.ok(new AuthResponseDTO(token, usuario.getNome(),
                usuario.getEmail(), usuario.getRole().name()));
    }
}
