package com.recrutatech.enums;
public enum RoleUsuario { ADMIN, RECRUTADOR, GESTOR }
