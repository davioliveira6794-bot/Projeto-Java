package com.recrutatech.repository;

import com.recrutatech.entity.Candidatura;
import com.recrutatech.enums.StatusCandidatura;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface CandidaturaRepository extends JpaRepository<Candidatura, Long> {
    List<Candidatura> findByVagaId(Long vagaId);
    List<Candidatura> findByCandidatoId(Long candidatoId);
    List<Candidatura> findByStatus(StatusCandidatura status);
    long countByVagaId(Long vagaId);

    @Query("SELECT c FROM Candidatura c WHERE c.vaga.id = :vagaId ORDER BY c.scoreIA DESC")
    List<Candidatura> findByVagaIdOrderedByScore(Long vagaId);

    @Query("SELECT COUNT(c) FROM Candidatura c")
    long totalCandidaturas();
}
