package com.recrutatech.service;

import com.recrutatech.dto.EntrevistaDTO;
import com.recrutatech.entity.Candidatura;
import com.recrutatech.entity.Entrevista;
import com.recrutatech.entity.Usuario;
import com.recrutatech.repository.CandidaturaRepository;
import com.recrutatech.repository.EntrevistaRepository;
import com.recrutatech.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EntrevistaService {

    private final EntrevistaRepository entrevistaRepository;
    private final CandidaturaRepository candidaturaRepository;
    private final UsuarioRepository usuarioRepository;

    public List<EntrevistaDTO> listarProximas() {
        return entrevistaRepository.findProximas().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public EntrevistaDTO agendar(EntrevistaDTO dto) {
        Candidatura candidatura = candidaturaRepository.findById(dto.getCandidaturaId())
                .orElseThrow(() -> new RuntimeException("Candidatura não encontrada"));
        Usuario entrevistador = dto.getEntrevistadorId() != null
                ? usuarioRepository.findById(dto.getEntrevistadorId()).orElse(null) : null;

        Entrevista e = Entrevista.builder()
                .candidatura(candidatura).entrevistador(entrevistador)
                .dataHora(dto.getDataHora()).tipo(dto.getTipo())
                .linkReuniao(dto.getLinkReuniao()).build();
        return toDTO(entrevistaRepository.save(e));
    }

    public EntrevistaDTO registrarFeedback(Long id, Integer nota, String feedback) {
        Entrevista e = entrevistaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Entrevista não encontrada"));
        e.setNota(nota); e.setFeedback(feedback); e.setRealizada(true);
        return toDTO(entrevistaRepository.save(e));
    }

    public EntrevistaDTO toDTO(Entrevista e) {
        EntrevistaDTO dto = new EntrevistaDTO();
        dto.setId(e.getId());
        dto.setCandidaturaId(e.getCandidatura().getId());
        dto.setCandidatoNome(e.getCandidatura().getCandidato().getNome());
        dto.setVagaTitulo(e.getCandidatura().getVaga().getTitulo());
        if (e.getEntrevistador() != null) {
            dto.setEntrevistadorId(e.getEntrevistador().getId());
            dto.setEntrevistadorNome(e.getEntrevistador().getNome());
        }
        dto.setDataHora(e.getDataHora()); dto.setTipo(e.getTipo());
        dto.setLinkReuniao(e.getLinkReuniao()); dto.setNota(e.getNota());
        dto.setFeedback(e.getFeedback()); dto.setRealizada(e.isRealizada());
        return dto;
    }
}
