package com.recrutatech.service;

import com.recrutatech.dto.CandidatoDTO;
import com.recrutatech.entity.Candidato;
import com.recrutatech.repository.CandidatoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CandidatoService {

    private final CandidatoRepository candidatoRepository;

    public List<CandidatoDTO> listarTodos() {
        return candidatoRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public CandidatoDTO buscarPorId(Long id) {
        return candidatoRepository.findById(id).map(this::toDTO)
                .orElseThrow(() -> new RuntimeException("Candidato não encontrado: " + id));
    }

    public CandidatoDTO criar(CandidatoDTO dto) {
        if (candidatoRepository.findByEmail(dto.getEmail()).isPresent())
            throw new RuntimeException("E-mail já cadastrado: " + dto.getEmail());
        return toDTO(candidatoRepository.save(toEntity(dto)));
    }

    public CandidatoDTO atualizar(Long id, CandidatoDTO dto) {
        Candidato c = candidatoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Candidato não encontrado: " + id));
        c.setNome(dto.getNome()); c.setTelefone(dto.getTelefone());
        c.setLinkedin(dto.getLinkedin()); c.setGithub(dto.getGithub());
        c.setCidade(dto.getCidade()); c.setEstado(dto.getEstado());
        c.setResumo(dto.getResumo()); c.setHabilidades(dto.getHabilidades());
        return toDTO(candidatoRepository.save(c));
    }

    public void deletar(Long id) { candidatoRepository.deleteById(id); }

    public List<CandidatoDTO> buscarPorNome(String nome) {
        return candidatoRepository.findByNomeContainingIgnoreCase(nome)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    private CandidatoDTO toDTO(Candidato c) {
        CandidatoDTO dto = new CandidatoDTO();
        dto.setId(c.getId()); dto.setNome(c.getNome()); dto.setEmail(c.getEmail());
        dto.setTelefone(c.getTelefone()); dto.setLinkedin(c.getLinkedin());
        dto.setGithub(c.getGithub()); dto.setCidade(c.getCidade());
        dto.setEstado(c.getEstado()); dto.setResumo(c.getResumo());
        dto.setHabilidades(c.getHabilidades());
        return dto;
    }

    private Candidato toEntity(CandidatoDTO dto) {
        return Candidato.builder()
                .nome(dto.getNome()).email(dto.getEmail()).telefone(dto.getTelefone())
                .linkedin(dto.getLinkedin()).github(dto.getGithub())
                .cidade(dto.getCidade()).estado(dto.getEstado())
                .resumo(dto.getResumo()).habilidades(dto.getHabilidades())
                .build();
    }
}
