package com.recrutatech.dto;

import com.recrutatech.enums.TipoEntrevista;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class EntrevistaDTO {
    private Long id;
    private Long candidaturaId;
    private String candidatoNome;
    private String vagaTitulo;
    private Long entrevistadorId;
    private String entrevistadorNome;
    private LocalDateTime dataHora;
    private TipoEntrevista tipo;
    private String linkReuniao;
    private Integer nota;
    private String feedback;
    private boolean realizada;
}
