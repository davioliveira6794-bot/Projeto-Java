package com.recrutatech.service;

import com.recrutatech.dto.VagaDTO;
import com.recrutatech.entity.Vaga;
import com.recrutatech.enums.StatusVaga;
import com.recrutatech.repository.CandidaturaRepository;
import com.recrutatech.repository.VagaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class VagaService {

    private final VagaRepository vagaRepository;
    private final CandidaturaRepository candidaturaRepository;

    public List<VagaDTO> listarTodas() {
        return vagaRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<VagaDTO> listarAbertas() {
        return vagaRepository.findByStatus(StatusVaga.ABERTA).stream().map(this::toDTO).collect(Collectors.toList());
    }

    public VagaDTO buscarPorId(Long id) {
        return vagaRepository.findById(id).map(this::toDTO)
                .orElseThrow(() -> new RuntimeException("Vaga não encontrada: " + id));
    }

    public VagaDTO criar(VagaDTO dto) {
        Vaga vaga = toEntity(dto);
        return toDTO(vagaRepository.save(vaga));
    }

    public VagaDTO atualizar(Long id, VagaDTO dto) {
        Vaga vaga = vagaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Vaga não encontrada: " + id));
        vaga.setTitulo(dto.getTitulo());
        vaga.setDescricao(dto.getDescricao());
        vaga.setArea(dto.getArea());
        vaga.setNivel(dto.getNivel());
        vaga.setModalidade(dto.getModalidade());
        vaga.setLocalizacao(dto.getLocalizacao());
        vaga.setSalario(dto.getSalario());
        vaga.setRequisitos(dto.getRequisitos());
        if (dto.getStatus() != null) vaga.setStatus(dto.getStatus());
        return toDTO(vagaRepository.save(vaga));
    }

    public void deletar(Long id) {
        vagaRepository.deleteById(id);
    }

    // Mapper helpers
    private VagaDTO toDTO(Vaga v) {
        VagaDTO dto = new VagaDTO();
        dto.setId(v.getId());
        dto.setTitulo(v.getTitulo());
        dto.setDescricao(v.getDescricao());
        dto.setArea(v.getArea());
        dto.setNivel(v.getNivel());
        dto.setModalidade(v.getModalidade());
        dto.setLocalizacao(v.getLocalizacao());
        dto.setSalario(v.getSalario());
        dto.setRequisitos(v.getRequisitos());
        dto.setStatus(v.getStatus());
        dto.setTotalCandidatos(candidaturaRepository.countByVagaId(v.getId()));
        return dto;
    }

    private Vaga toEntity(VagaDTO dto) {
        return Vaga.builder()
                .titulo(dto.getTitulo())
                .descricao(dto.getDescricao())
                .area(dto.getArea())
                .nivel(dto.getNivel())
                .modalidade(dto.getModalidade())
                .localizacao(dto.getLocalizacao())
                .salario(dto.getSalario())
                .requisitos(dto.getRequisitos())
                .status(dto.getStatus() != null ? dto.getStatus() : StatusVaga.ABERTA)
                .build();
    }
}
