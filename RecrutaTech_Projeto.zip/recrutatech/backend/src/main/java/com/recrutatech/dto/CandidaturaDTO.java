package com.recrutatech.dto;

import com.recrutatech.enums.StatusCandidatura;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class CandidaturaDTO {
    private Long id;
    private Long candidatoId;
    private String candidatoNome;
    private Long vagaId;
    private String vagaTitulo;
    private StatusCandidatura status;
    private Integer scoreIA;
    private String observacoes;
    private LocalDateTime inscritoEm;
}
