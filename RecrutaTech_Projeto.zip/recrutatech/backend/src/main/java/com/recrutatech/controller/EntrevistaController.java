package com.recrutatech.controller;

import com.recrutatech.dto.EntrevistaDTO;
import com.recrutatech.service.EntrevistaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/entrevistas")
@RequiredArgsConstructor
public class EntrevistaController {

    private final EntrevistaService entrevistaService;

    @GetMapping("/proximas")
    public List<EntrevistaDTO> proximas() { return entrevistaService.listarProximas(); }

    @PostMapping
    public ResponseEntity<EntrevistaDTO> agendar(@RequestBody EntrevistaDTO dto) {
        return ResponseEntity.ok(entrevistaService.agendar(dto));
    }

    @PatchMapping("/{id}/feedback")
    public ResponseEntity<EntrevistaDTO> feedback(
            @PathVariable Long id,
            @RequestParam Integer nota,
            @RequestParam String feedback) {
        return ResponseEntity.ok(entrevistaService.registrarFeedback(id, nota, feedback));
    }
}
