package com.recrutatech.enums;
public enum StatusCandidatura { INSCRITO, TRIAGEM, ENTREVISTA, TECNICO, OFERTA, APROVADO, REPROVADO }
