package com.recrutatech.repository;

import com.recrutatech.entity.Entrevista;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.time.LocalDateTime;
import java.util.List;

public interface EntrevistaRepository extends JpaRepository<Entrevista, Long> {
    List<Entrevista> findByCandidaturaId(Long candidaturaId);
    List<Entrevista> findByEntrevistadorId(Long entrevistadorId);

    @Query("SELECT e FROM Entrevista e WHERE e.dataHora BETWEEN :inicio AND :fim ORDER BY e.dataHora")
    List<Entrevista> findByPeriodo(LocalDateTime inicio, LocalDateTime fim);

    @Query("SELECT e FROM Entrevista e WHERE e.dataHora >= CURRENT_TIMESTAMP AND e.realizada = false ORDER BY e.dataHora")
    List<Entrevista> findProximas();
}
