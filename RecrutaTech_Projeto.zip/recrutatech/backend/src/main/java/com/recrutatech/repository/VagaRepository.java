package com.recrutatech.repository;

import com.recrutatech.entity.Vaga;
import com.recrutatech.enums.StatusVaga;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface VagaRepository extends JpaRepository<Vaga, Long> {
    List<Vaga> findByStatus(StatusVaga status);
    List<Vaga> findByAreaContainingIgnoreCase(String area);
    long countByStatus(StatusVaga status);

    @Query("SELECT v FROM Vaga v WHERE v.status = 'ABERTA' ORDER BY v.criadaEm DESC")
    List<Vaga> findVagasAbertasRecentes();
}
