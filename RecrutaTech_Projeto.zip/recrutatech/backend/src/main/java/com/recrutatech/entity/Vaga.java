package com.recrutatech.entity;

import com.recrutatech.enums.StatusVaga;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity @Table(name = "vagas")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Vaga {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String titulo;

    @Column(columnDefinition = "TEXT")
    private String descricao;

    private String area;
    private String nivel;          // Junior, Pleno, Senior
    private String modalidade;     // Remoto, Híbrido, Presencial
    private String localizacao;
    private Double salario;

    @ElementCollection
    @CollectionTable(name = "vaga_requisitos", joinColumns = @JoinColumn(name = "vaga_id"))
    @Column(name = "requisito")
    private List<String> requisitos;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusVaga status = StatusVaga.ABERTA;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "criado_por")
    private Usuario criadoPor;

    @Column(updatable = false)
    private LocalDateTime criadaEm = LocalDateTime.now();

    private LocalDateTime encerradaEm;
}
