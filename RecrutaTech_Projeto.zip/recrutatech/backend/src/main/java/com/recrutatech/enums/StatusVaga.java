package com.recrutatech.enums;
public enum StatusVaga { ABERTA, PAUSADA, ENCERRADA }
