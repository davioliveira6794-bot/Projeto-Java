package com.recrutatech.repository;

import com.recrutatech.entity.Candidato;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface CandidatoRepository extends JpaRepository<Candidato, Long> {
    Optional<Candidato> findByEmail(String email);
    List<Candidato> findByNomeContainingIgnoreCase(String nome);

    @Query("SELECT c FROM Candidato c WHERE :habilidade MEMBER OF c.habilidades")
    List<Candidato> findByHabilidade(String habilidade);
}
