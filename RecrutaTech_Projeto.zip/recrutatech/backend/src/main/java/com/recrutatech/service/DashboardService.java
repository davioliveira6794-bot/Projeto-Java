package com.recrutatech.service;

import com.recrutatech.dto.DashboardDTO;
import com.recrutatech.dto.EntrevistaDTO;
import com.recrutatech.enums.StatusCandidatura;
import com.recrutatech.enums.StatusVaga;
import com.recrutatech.repository.CandidatoRepository;
import com.recrutatech.repository.CandidaturaRepository;
import com.recrutatech.repository.EntrevistaRepository;
import com.recrutatech.repository.VagaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final CandidatoRepository candidatoRepo;
    private final VagaRepository vagaRepo;
    private final CandidaturaRepository candidaturaRepo;
    private final EntrevistaRepository entrevistaRepo;
    private final EntrevistaService entrevistaService;

    public DashboardDTO getDashboard() {
        Map<String, Long> funil = new LinkedHashMap<>();
        for (StatusCandidatura s : StatusCandidatura.values())
            funil.put(s.name(), candidaturaRepo.findByStatus(s).size());

        List<EntrevistaDTO> proximas = entrevistaRepo.findProximas()
                .stream().limit(5).map(entrevistaService::toDTO).collect(Collectors.toList());

        return DashboardDTO.builder()
                .totalCandidatosAtivos(candidatoRepo.count())
                .vagasAbertas(vagaRepo.countByStatus(StatusVaga.ABERTA))
                .diasMediosContratacao(5L)
                .entrevistasHoje(entrevistaRepo.findByPeriodo(
                        LocalDateTime.now().withHour(0).withMinute(0),
                        LocalDateTime.now().withHour(23).withMinute(59)).size())
                .funil(funil)
                .proximasEntrevistas(proximas)
                .build();
    }
}
