package com.recrutatech.controller;

import com.recrutatech.dto.CandidatoDTO;
import com.recrutatech.service.CandidatoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/candidatos")
@RequiredArgsConstructor
public class CandidatoController {

    private final CandidatoService candidatoService;

    @GetMapping
    public List<CandidatoDTO> listar(@RequestParam(required = false) String nome) {
        return nome != null ? candidatoService.buscarPorNome(nome) : candidatoService.listarTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<CandidatoDTO> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(candidatoService.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<CandidatoDTO> criar(@Valid @RequestBody CandidatoDTO dto) {
        return ResponseEntity.ok(candidatoService.criar(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CandidatoDTO> atualizar(@PathVariable Long id, @Valid @RequestBody CandidatoDTO dto) {
        return ResponseEntity.ok(candidatoService.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        candidatoService.deletar(id); return ResponseEntity.noContent().build();
    }
}
