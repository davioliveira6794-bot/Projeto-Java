package com.recrutatech.controller;

import com.recrutatech.dto.CandidaturaDTO;
import com.recrutatech.enums.StatusCandidatura;
import com.recrutatech.service.CandidaturaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/candidaturas")
@RequiredArgsConstructor
public class CandidaturaController {

    private final CandidaturaService candidaturaService;

    @GetMapping("/vaga/{vagaId}")
    public List<CandidaturaDTO> porVaga(@PathVariable Long vagaId) {
        return candidaturaService.listarPorVaga(vagaId);
    }

    @GetMapping("/candidato/{candidatoId}")
    public List<CandidaturaDTO> porCandidato(@PathVariable Long candidatoId) {
        return candidaturaService.listarPorCandidato(candidatoId);
    }

    @PostMapping("/inscrever")
    public ResponseEntity<CandidaturaDTO> inscrever(
            @RequestParam Long candidatoId, @RequestParam Long vagaId) {
        return ResponseEntity.ok(candidaturaService.inscrever(candidatoId, vagaId));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<CandidaturaDTO> atualizarStatus(
            @PathVariable Long id, @RequestParam StatusCandidatura status) {
        return ResponseEntity.ok(candidaturaService.atualizarStatus(id, status));
    }
}
