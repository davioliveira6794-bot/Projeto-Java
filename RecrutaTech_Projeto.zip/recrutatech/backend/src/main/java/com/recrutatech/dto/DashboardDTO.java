package com.recrutatech.dto;

import lombok.Builder;
import lombok.Data;
import java.util.List;
import java.util.Map;

@Data @Builder
public class DashboardDTO {
    private long totalCandidatosAtivos;
    private long vagasAbertas;
    private long diasMediosContratacao;
    private long entrevistasHoje;
    private Map<String, Long> funil;        // etapa -> quantidade
    private List<EntrevistaDTO> proximasEntrevistas;
    private List<CandidaturaDTO> ultimasCandidaturas;
}
