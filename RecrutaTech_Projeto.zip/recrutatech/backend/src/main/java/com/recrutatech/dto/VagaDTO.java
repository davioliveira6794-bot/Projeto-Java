package com.recrutatech.dto;

import com.recrutatech.enums.StatusVaga;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.util.List;

@Data
public class VagaDTO {
    private Long id;
    @NotBlank(message = "Título é obrigatório")
    private String titulo;
    private String descricao;
    private String area;
    private String nivel;
    private String modalidade;
    private String localizacao;
    private Double salario;
    private List<String> requisitos;
    private StatusVaga status;
    private long totalCandidatos;
}
