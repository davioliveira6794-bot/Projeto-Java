package com.recrutatech.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Entidade Candidato — representa um candidato no processo seletivo
 */
@Entity
@Table(name = "candidatos")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Candidato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nome é obrigatório")
    @Size(max = 100)
    @Column(nullable = false)
    private String nome;

    @NotBlank(message = "Email é obrigatório")
    @Email(message = "Email inválido")
    @Column(nullable = false, unique = true)
    private String email;

    @Size(max = 20)
    private String telefone;

    @Size(max = 100)
    private String cargoAtual;

    @Size(max = 500)
    private String resumo;

    /** Score de aderência calculado pela IA (0-100) */
    @Min(0) @Max(100)
    @Column(name = "score_ia")
    private Integer scoreIa;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusCandidato status;

    @Column(name = "criado_em")
    private LocalDateTime criadoEm;

    @Column(name = "atualizado_em")
    private LocalDateTime atualizadoEm;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vaga_id")
    private Vaga vaga;

    @PrePersist
    protected void onCreate() {
        criadoEm = LocalDateTime.now();
        atualizadoEm = LocalDateTime.now();
        if (status == null) status = StatusCandidato.INSCRITO;
    }

    @PreUpdate
    protected void onUpdate() {
        atualizadoEm = LocalDateTime.now();
    }

    public enum StatusCandidato {
        INSCRITO,
        TRIAGEM_IA,
        ENTREVISTA,
        TECNICO,
        OFERTA,
        APROVADO,
        REPROVADO
    }
}
