package com.recrutatech.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity @Table(name = "candidatos")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Candidato {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String nome;

    @Email @NotBlank
    @Column(nullable = false, unique = true)
    private String email;

    private String telefone;
    private String linkedin;
    private String github;
    private String cidade;
    private String estado;

    @Column(columnDefinition = "TEXT")
    private String resumo;

    @ElementCollection
    @CollectionTable(name = "candidato_habilidades", joinColumns = @JoinColumn(name = "candidato_id"))
    @Column(name = "habilidade")
    private List<String> habilidades;

    @Column(updatable = false)
    private LocalDateTime cadastradoEm = LocalDateTime.now();
}
