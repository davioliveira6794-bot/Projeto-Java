package com.recrutatech.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.util.List;

@Data
public class CandidatoDTO {
    private Long id;
    @NotBlank(message = "Nome é obrigatório")
    private String nome;
    @Email(message = "E-mail inválido")
    private String email;
    private String telefone;
    private String linkedin;
    private String github;
    private String cidade;
    private String estado;
    private String resumo;
    private List<String> habilidades;
}
