package com.recrutatech.service;

import com.recrutatech.dto.CandidaturaDTO;
import com.recrutatech.entity.Candidato;
import com.recrutatech.entity.Candidatura;
import com.recrutatech.entity.Vaga;
import com.recrutatech.enums.StatusCandidatura;
import com.recrutatech.repository.CandidatoRepository;
import com.recrutatech.repository.CandidaturaRepository;
import com.recrutatech.repository.VagaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CandidaturaService {

    private final CandidaturaRepository candidaturaRepository;
    private final CandidatoRepository candidatoRepository;
    private final VagaRepository vagaRepository;

    public List<CandidaturaDTO> listarPorVaga(Long vagaId) {
        return candidaturaRepository.findByVagaIdOrderedByScore(vagaId)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<CandidaturaDTO> listarPorCandidato(Long candidatoId) {
        return candidaturaRepository.findByCandidatoId(candidatoId)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    public CandidaturaDTO inscrever(Long candidatoId, Long vagaId) {
        Candidato candidato = candidatoRepository.findById(candidatoId)
                .orElseThrow(() -> new RuntimeException("Candidato não encontrado"));
        Vaga vaga = vagaRepository.findById(vagaId)
                .orElseThrow(() -> new RuntimeException("Vaga não encontrada"));

        // Score simulado por IA (em produção: integrar com modelo ML)
        int scoreIA = calcularScoreIA(candidato, vaga);

        Candidatura c = Candidatura.builder()
                .candidato(candidato).vaga(vaga)
                .status(StatusCandidatura.INSCRITO).scoreIA(scoreIA).build();
        return toDTO(candidaturaRepository.save(c));
    }

    public CandidaturaDTO atualizarStatus(Long id, StatusCandidatura novoStatus) {
        Candidatura c = candidaturaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Candidatura não encontrada"));
        c.setStatus(novoStatus);
        return toDTO(candidaturaRepository.save(c));
    }

    /** Simula score de IA baseado em match de habilidades */
    private int calcularScoreIA(Candidato candidato, Vaga vaga) {
        if (vaga.getRequisitos() == null || vaga.getRequisitos().isEmpty()) return 50;
        long matches = vaga.getRequisitos().stream()
                .filter(r -> candidato.getHabilidades() != null &&
                        candidato.getHabilidades().stream().anyMatch(h -> h.equalsIgnoreCase(r)))
                .count();
        int base = (int) ((matches * 100.0) / vaga.getRequisitos().size());
        return Math.min(100, base + new Random().nextInt(15)); // +fator aleatorio (simulação)
    }

    private CandidaturaDTO toDTO(Candidatura c) {
        CandidaturaDTO dto = new CandidaturaDTO();
        dto.setId(c.getId());
        dto.setCandidatoId(c.getCandidato().getId());
        dto.setCandidatoNome(c.getCandidato().getNome());
        dto.setVagaId(c.getVaga().getId());
        dto.setVagaTitulo(c.getVaga().getTitulo());
        dto.setStatus(c.getStatus());
        dto.setScoreIA(c.getScoreIA());
        dto.setObservacoes(c.getObservacoes());
        dto.setInscritoEm(c.getInscritoEm());
        return dto;
    }
}
