package com.recrutatech.entity;

import com.recrutatech.enums.TipoEntrevista;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name = "entrevistas")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Entrevista {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "candidatura_id", nullable = false)
    private Candidatura candidatura;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "entrevistador_id")
    private Usuario entrevistador;

    @Column(nullable = false)
    private LocalDateTime dataHora;

    @Enumerated(EnumType.STRING)
    private TipoEntrevista tipo;

    private String linkReuniao;
    private Integer nota;            // 1–10

    @Column(columnDefinition = "TEXT")
    private String feedback;

    private boolean realizada = false;
}
