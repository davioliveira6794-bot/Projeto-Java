package com.recrutatech;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecrutatechApplication {
    public static void main(String[] args) {
        SpringApplication.run(RecrutatechApplication.class, args);
    }
}
