package com.recrutatech.controller;

import com.recrutatech.dto.VagaDTO;
import com.recrutatech.service.VagaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/vagas")
@RequiredArgsConstructor
public class VagaController {

    private final VagaService vagaService;

    @GetMapping
    public List<VagaDTO> listarTodas() { return vagaService.listarTodas(); }

    @GetMapping("/abertas")
    public List<VagaDTO> listarAbertas() { return vagaService.listarAbertas(); }

    @GetMapping("/{id}")
    public ResponseEntity<VagaDTO> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(vagaService.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<VagaDTO> criar(@Valid @RequestBody VagaDTO dto) {
        return ResponseEntity.ok(vagaService.criar(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<VagaDTO> atualizar(@PathVariable Long id, @Valid @RequestBody VagaDTO dto) {
        return ResponseEntity.ok(vagaService.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        vagaService.deletar(id); return ResponseEntity.noContent().build();
    }
}
