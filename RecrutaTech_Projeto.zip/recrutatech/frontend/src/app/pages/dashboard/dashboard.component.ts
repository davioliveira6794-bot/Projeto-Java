import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../core/services/dashboard.service';
import { Dashboard } from '../../core/models/dashboard.model';

@Component({ selector: 'app-dashboard', templateUrl: './dashboard.component.html', styleUrls: ['./dashboard.component.scss'] })
export class DashboardComponent implements OnInit {
  data?: Dashboard;
  loading = true;

  // Mock data for when backend is not available
  mockData: Dashboard = {
    totalCandidatosAtivos: 47,
    vagasAbertas: 12,
    diasMediosContratacao: 5,
    entrevistasHoje: 3,
    funil: { INSCRITO: 320, TRIAGEM: 245, ENTREVISTA: 140, TECNICO: 80, OFERTA: 42, APROVADO: 18, REPROVADO: 15 },
    proximasEntrevistas: [
      { id: 1, candidaturaId: 1, candidatoNome: 'Lucas F.', vagaTitulo: 'Dev Sr', dataHora: '2026-03-11T10:00', tipo: 'TECNICA' },
      { id: 2, candidaturaId: 2, candidatoNome: 'Mariana C.', vagaTitulo: 'UX', dataHora: '2026-03-11T14:00', tipo: 'COMPORTAMENTAL' },
      { id: 3, candidaturaId: 3, candidatoNome: 'Pedro A.', vagaTitulo: 'Data', dataHora: '2026-03-11T16:30', tipo: 'ONLINE' },
    ],
    ultimasCandidaturas: [
      { id: 1, candidatoId: 1, candidatoNome: 'Lucas Ferreira', vagaId: 1, vagaTitulo: 'Dev Backend Sr', status: 'TRIAGEM', scoreIA: 96 },
      { id: 2, candidatoId: 2, candidatoNome: 'Mariana Costa', vagaId: 2, vagaTitulo: 'UX Designer', status: 'ENTREVISTA', scoreIA: 88 },
      { id: 3, candidatoId: 3, candidatoNome: 'Pedro Alves', vagaId: 3, vagaTitulo: 'Data Analyst', status: 'TECNICO', scoreIA: 72 },
      { id: 4, candidatoId: 4, candidatoNome: 'Sofia Lima', vagaId: 4, vagaTitulo: 'Product Manager', status: 'APROVADO', scoreIA: 95 },
    ]
  };

  constructor(private dashboardService: DashboardService) {}

  ngOnInit() {
    this.dashboardService.getDashboard().subscribe({
      next: d => { this.data = d; this.loading = false; },
      error: () => { this.data = this.mockData; this.loading = false; }
    });
  }

  get funilEntries() { return this.data ? Object.entries(this.data.funil) : []; }

  maxFunil(): number {
    if (!this.data) return 1;
    return Math.max(...Object.values(this.data.funil));
  }

  statusBadge(s: string): string {
    const map: any = { INSCRITO:'neutral', TRIAGEM:'info', ENTREVISTA:'info', TECNICO:'warning', OFERTA:'warning', APROVADO:'success', REPROVADO:'danger' };
    return map[s] || 'neutral';
  }

  statusLabel(s: string): string {
    const map: any = { INSCRITO:'Inscrito', TRIAGEM:'Triagem IA', ENTREVISTA:'Entrevista', TECNICO:'Técnico', OFERTA:'Oferta', APROVADO:'Aprovado', REPROVADO:'Reprovado' };
    return map[s] || s;
  }

  tipoLabel(t: string): string {
    const map: any = { ONLINE:'Online', PRESENCIAL:'Presencial', TECNICA:'Técnica', COMPORTAMENTAL:'Comportamental' };
    return map[t] || t;
  }

  formatHour(dt: string): string {
    return new Date(dt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  }
}
