import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({ selector: 'app-login', templateUrl: './login.component.html', styleUrls: ['./login.component.scss'] })
export class LoginComponent {
  email = ''; senha = ''; loading = false; error = '';

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit() {
    this.loading = true; this.error = '';
    this.auth.login(this.email, this.senha).subscribe({
      next: () => this.router.navigate(['/dashboard']),
      error: () => { this.error = 'E-mail ou senha incorretos.'; this.loading = false; }
    });
  }
}
