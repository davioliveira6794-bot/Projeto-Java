import { Component, OnInit } from '@angular/core';
import { Entrevista, TipoEntrevista } from '../../core/models/entrevista.model';

@Component({ selector: 'app-entrevistas', templateUrl: './entrevistas.component.html', styleUrls: ['./entrevistas.component.scss'] })
export class EntrevistasComponent implements OnInit {
  entrevistas: Entrevista[] = [
    { id:1, candidaturaId:1, candidatoNome:'Lucas Ferreira', vagaTitulo:'Dev Backend Sr', dataHora:'2026-03-11T10:00', tipo:'TECNICA', entrevistadorNome:'Ana Paula', realizada:false },
    { id:2, candidaturaId:2, candidatoNome:'Mariana Costa', vagaTitulo:'UX Designer', dataHora:'2026-03-11T14:00', tipo:'COMPORTAMENTAL', entrevistadorNome:'Carlos M.', realizada:false },
    { id:3, candidaturaId:3, candidatoNome:'Pedro Alves', vagaTitulo:'Data Analyst', dataHora:'2026-03-11T16:30', tipo:'ONLINE', entrevistadorNome:'Ana Paula', realizada:false },
    { id:4, candidaturaId:4, candidatoNome:'Sofia Lima', vagaTitulo:'Product Manager', dataHora:'2026-03-10T09:00', tipo:'PRESENCIAL', entrevistadorNome:'Marcos T.', realizada:true, nota:9, feedback:'Excelente candidata.' },
  ];

  tipoColors: Record<TipoEntrevista, string> = { ONLINE:'info', PRESENCIAL:'success', TECNICA:'warning', COMPORTAMENTAL:'neutral' };
  tipoLabels: Record<TipoEntrevista, string> = { ONLINE:'Online', PRESENCIAL:'Presencial', TECNICA:'Técnica', COMPORTAMENTAL:'Comportamental' };

  ngOnInit() {}

  get proximas() { return this.entrevistas.filter(e => !e.realizada); }
  get realizadas() { return this.entrevistas.filter(e => e.realizada); }

  formatDate(dt: string) { return new Date(dt).toLocaleDateString('pt-BR', { day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit' }); }
  initials(nome: string) { return nome.split(' ').slice(0,2).map(n=>n[0]).join('').toUpperCase(); }

  stars(nota?: number) { return Array.from({length: 10}, (_, i) => i < (nota || 0)); }
}
