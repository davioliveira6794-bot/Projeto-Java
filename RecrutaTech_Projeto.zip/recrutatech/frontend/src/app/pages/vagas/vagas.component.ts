import { Component, OnInit } from '@angular/core';
import { VagaService } from '../../core/services/vaga.service';
import { Vaga, StatusVaga } from '../../core/models/vaga.model';

@Component({ selector: 'app-vagas', templateUrl: './vagas.component.html', styleUrls: ['./vagas.component.scss'] })
export class VagasComponent implements OnInit {
  vagas: Vaga[] = [];
  showForm = false;
  editando?: Vaga;
  form: Partial<Vaga> = {};
  loading = true;

  niveis = ['Estágio','Júnior','Pleno','Sênior'];
  modalidades = ['Remoto','Híbrido','Presencial'];
  statusOpts: StatusVaga[] = ['ABERTA','PAUSADA','ENCERRADA'];

  mockVagas: Vaga[] = [
    { id: 1, titulo: 'Dev Backend Sênior', area: 'Tecnologia', nivel: 'Sênior', modalidade: 'Remoto', localizacao: 'Brasil', status: 'ABERTA', totalCandidatos: 87, requisitos: ['Java','Spring','PostgreSQL'] },
    { id: 2, titulo: 'UX Designer', area: 'Design', nivel: 'Pleno', modalidade: 'Híbrido', localizacao: 'São Paulo', status: 'ABERTA', totalCandidatos: 34, requisitos: ['Figma','UX Research'] },
    { id: 3, titulo: 'Data Analyst', area: 'Dados', nivel: 'Pleno', modalidade: 'Remoto', localizacao: 'Brasil', status: 'PAUSADA', totalCandidatos: 22, requisitos: ['Python','SQL','PowerBI'] },
    { id: 4, titulo: 'Product Manager', area: 'Produto', nivel: 'Sênior', modalidade: 'Híbrido', localizacao: 'Rio de Janeiro', status: 'ABERTA', totalCandidatos: 56, requisitos: ['Agile','Scrum'] },
  ];

  constructor(private vagaService: VagaService) {}

  ngOnInit() {
    this.vagaService.listar().subscribe({
      next: v => { this.vagas = v; this.loading = false; },
      error: () => { this.vagas = this.mockVagas; this.loading = false; }
    });
  }

  abrirForm(v?: Vaga) {
    this.editando = v;
    this.form = v ? { ...v } : { status: 'ABERTA' };
    this.showForm = true;
  }

  salvar() {
    if (this.editando?.id) {
      this.vagaService.atualizar(this.editando.id, this.form as Vaga).subscribe({
        next: updated => { this.vagas = this.vagas.map(v => v.id === updated.id ? updated : v); this.showForm = false; },
        error: () => { this.vagas = this.vagas.map(v => v.id === this.editando?.id ? { ...v, ...this.form } : v); this.showForm = false; }
      });
    } else {
      this.vagaService.criar(this.form as Vaga).subscribe({
        next: created => { this.vagas.unshift(created); this.showForm = false; },
        error: () => { this.vagas.unshift({ ...this.form, id: Date.now() } as Vaga); this.showForm = false; }
      });
    }
  }

  deletar(id: number) {
    if (!confirm('Confirma exclusão?')) return;
    this.vagaService.deletar(id).subscribe({
      next: () => this.vagas = this.vagas.filter(v => v.id !== id),
      error: () => this.vagas = this.vagas.filter(v => v.id !== id)
    });
  }

  statusBadge(s?: StatusVaga) {
    const m: any = { ABERTA: 'success', PAUSADA: 'warning', ENCERRADA: 'danger' };
    return m[s!] || 'neutral';
  }

  statusIcon(s?: StatusVaga) {
    const m: any = { ABERTA: 'check_circle', PAUSADA: 'pause_circle', ENCERRADA: 'cancel' };
    return m[s!] || 'circle';
  }
}
