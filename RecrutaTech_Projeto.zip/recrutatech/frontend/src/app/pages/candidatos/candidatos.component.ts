import { Component, OnInit } from '@angular/core';
import { CandidatoService } from '../../core/services/candidato.service';
import { Candidato } from '../../core/models/candidato.model';

@Component({ selector: 'app-candidatos', templateUrl: './candidatos.component.html', styleUrls: ['./candidatos.component.scss'] })
export class CandidatosComponent implements OnInit {
  candidatos: Candidato[] = [];
  showForm = false;
  editando?: Candidato;
  form: Partial<Candidato> = {};
  search = '';

  mockCandidatos: Candidato[] = [
    { id: 1, nome: 'Thiago Santos', email: 'thiago@email.com', cidade: 'São Paulo', estado: 'SP', habilidades: ['Python/Django','Java','Spring'] },
    { id: 2, nome: 'Camila Rocha', email: 'camila@email.com', cidade: 'Rio de Janeiro', estado: 'RJ', habilidades: ['Figma','UX Research','Prototyping'] },
    { id: 3, nome: 'Bruno Neves', email: 'bruno@email.com', cidade: 'Belo Horizonte', estado: 'MG', habilidades: ['Python','Django','PostgreSQL'] },
    { id: 4, nome: 'Juliana Melo', email: 'juliana@email.com', cidade: 'Curitiba', estado: 'PR', habilidades: ['Angular','TypeScript','Node.js'] },
    { id: 5, nome: 'Rafael Dias', email: 'rafael@email.com', cidade: 'Porto Alegre', estado: 'RS', habilidades: ['React','Node.js','AWS'] },
  ];

  constructor(private candidatoService: CandidatoService) {}

  ngOnInit() {
    this.candidatoService.listar().subscribe({
      next: c => this.candidatos = c,
      error: () => this.candidatos = this.mockCandidatos
    });
  }

  filtrados() {
    if (!this.search) return this.candidatos;
    const q = this.search.toLowerCase();
    return this.candidatos.filter(c =>
      c.nome.toLowerCase().includes(q) || c.email.toLowerCase().includes(q) ||
      (c.habilidades || []).some(h => h.toLowerCase().includes(q))
    );
  }

  abrirForm(c?: Candidato) {
    this.editando = c;
    this.form = c ? { ...c, habilidades: [...(c.habilidades || [])] } : {};
    this.showForm = true;
  }

  get habilidadesInput(): string { return (this.form.habilidades || []).join(', '); }
  set habilidadesInput(val: string) { this.form.habilidades = val.split(',').map(h => h.trim()).filter(h => h); }

  salvar() {
    if (this.editando?.id) {
      this.candidatoService.atualizar(this.editando.id, this.form as Candidato).subscribe({
        next: u => { this.candidatos = this.candidatos.map(c => c.id === u.id ? u : c); this.showForm = false; },
        error: () => { this.candidatos = this.candidatos.map(c => c.id === this.editando?.id ? { ...c, ...this.form } : c); this.showForm = false; }
      });
    } else {
      this.candidatoService.criar(this.form as Candidato).subscribe({
        next: c => { this.candidatos.unshift(c); this.showForm = false; },
        error: () => { this.candidatos.unshift({ ...this.form, id: Date.now() } as Candidato); this.showForm = false; }
      });
    }
  }

  deletar(id: number) {
    if (!confirm('Confirmar exclusão?')) return;
    this.candidatoService.deletar(id).subscribe({
      next: () => this.candidatos = this.candidatos.filter(c => c.id !== id),
      error: () => this.candidatos = this.candidatos.filter(c => c.id !== id)
    });
  }

  initials(nome: string) { return nome.split(' ').slice(0,2).map(n=>n[0]).join('').toUpperCase(); }
}
