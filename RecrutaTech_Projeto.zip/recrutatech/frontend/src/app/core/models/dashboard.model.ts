import { Candidatura } from './candidatura.model';
import { Entrevista } from './entrevista.model';

export interface Dashboard {
  totalCandidatosAtivos: number;
  vagasAbertas: number;
  diasMediosContratacao: number;
  entrevistasHoje: number;
  funil: Record<string, number>;
  proximasEntrevistas: Entrevista[];
  ultimasCandidaturas: Candidatura[];
}
