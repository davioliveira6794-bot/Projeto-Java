export type StatusCandidatura = 'INSCRITO'|'TRIAGEM'|'ENTREVISTA'|'TECNICO'|'OFERTA'|'APROVADO'|'REPROVADO';

export interface Candidatura {
  id?: number;
  candidatoId: number;
  candidatoNome?: string;
  vagaId: number;
  vagaTitulo?: string;
  status?: StatusCandidatura;
  scoreIA?: number;
  observacoes?: string;
  inscritoEm?: string;
}
