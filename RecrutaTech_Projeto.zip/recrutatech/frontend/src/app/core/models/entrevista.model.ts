export type TipoEntrevista = 'ONLINE'|'PRESENCIAL'|'TECNICA'|'COMPORTAMENTAL';

export interface Entrevista {
  id?: number;
  candidaturaId: number;
  candidatoNome?: string;
  vagaTitulo?: string;
  entrevistadorId?: number;
  entrevistadorNome?: string;
  dataHora: string;
  tipo?: TipoEntrevista;
  linkReuniao?: string;
  nota?: number;
  feedback?: string;
  realizada?: boolean;
}
