export type StatusVaga = 'ABERTA' | 'PAUSADA' | 'ENCERRADA';

export interface Vaga {
  id?: number;
  titulo: string;
  descricao?: string;
  area?: string;
  nivel?: string;
  modalidade?: string;
  localizacao?: string;
  salario?: number;
  requisitos?: string[];
  status?: StatusVaga;
  totalCandidatos?: number;
}
