export interface Candidato {
  id?: number;
  nome: string;
  email: string;
  telefone?: string;
  linkedin?: string;
  github?: string;
  cidade?: string;
  estado?: string;
  resumo?: string;
  habilidades?: string[];
}
