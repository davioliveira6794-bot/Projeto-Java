import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { Router } from '@angular/router';

export interface AuthUser { token: string; nome: string; email: string; role: string; }

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = 'http://localhost:8080/api/auth';
  private userSubject = new BehaviorSubject<AuthUser | null>(this.loadUser());
  user$ = this.userSubject.asObservable();

  constructor(private http: HttpClient, private router: Router) {}

  login(email: string, senha: string): Observable<AuthUser> {
    return this.http.post<AuthUser>(`${this.apiUrl}/login`, { email, senha }).pipe(
      tap(user => { localStorage.setItem('auth_user', JSON.stringify(user)); this.userSubject.next(user); })
    );
  }

  logout() {
    localStorage.removeItem('auth_user');
    this.userSubject.next(null);
    this.router.navigate(['/login']);
  }

  getToken(): string | null { return this.userSubject.value?.token ?? null; }
  isLoggedIn(): boolean { return !!this.userSubject.value; }
  getUser(): AuthUser | null { return this.userSubject.value; }

  private loadUser(): AuthUser | null {
    try { return JSON.parse(localStorage.getItem('auth_user') || 'null'); }
    catch { return null; }
  }
}
