import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';
import { Vaga } from '../models/vaga.model';

@Injectable({ providedIn: 'root' })
export class VagaService {
  constructor(private api: ApiService) {}

  listar(): Observable<Vaga[]>        { return this.api.get<Vaga[]>('/vagas'); }
  buscar(id: number): Observable<Vaga>{ return this.api.get<Vaga>(`/vagas/${id}`); }
  criar(v: Vaga): Observable<Vaga>    { return this.api.post<Vaga>('/vagas', v); }
  atualizar(id: number, v: Vaga): Observable<Vaga> { return this.api.put<Vaga>(`/vagas/${id}`, v); }
  deletar(id: number): Observable<void>{ return this.api.delete<void>(`/vagas/${id}`); }
}
