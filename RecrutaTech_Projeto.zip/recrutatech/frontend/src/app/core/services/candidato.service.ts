import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';
import { Candidato } from '../models/candidato.model';

@Injectable({ providedIn: 'root' })
export class CandidatoService {
  constructor(private api: ApiService) {}

  listar(nome?: string): Observable<Candidato[]> {
    return this.api.get<Candidato[]>(nome ? `/candidatos?nome=${nome}` : '/candidatos');
  }
  buscar(id: number): Observable<Candidato>          { return this.api.get<Candidato>(`/candidatos/${id}`); }
  criar(c: Candidato): Observable<Candidato>         { return this.api.post<Candidato>('/candidatos', c); }
  atualizar(id: number, c: Candidato): Observable<Candidato> { return this.api.put<Candidato>(`/candidatos/${id}`, c); }
  deletar(id: number): Observable<void>              { return this.api.delete<void>(`/candidatos/${id}`); }
}
