import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';
import { Candidatura, StatusCandidatura } from '../models/candidatura.model';

@Injectable({ providedIn: 'root' })
export class CandidaturaService {
  constructor(private api: ApiService) {}

  porVaga(vagaId: number): Observable<Candidatura[]>  { return this.api.get<Candidatura[]>(`/candidaturas/vaga/${vagaId}`); }
  porCandidato(cId: number): Observable<Candidatura[]>{ return this.api.get<Candidatura[]>(`/candidaturas/candidato/${cId}`); }
  inscrever(candidatoId: number, vagaId: number): Observable<Candidatura> {
    return this.api.post<Candidatura>(`/candidaturas/inscrever?candidatoId=${candidatoId}&vagaId=${vagaId}`, {});
  }
  atualizarStatus(id: number, status: StatusCandidatura): Observable<Candidatura> {
    return this.api.patch<Candidatura>(`/candidaturas/${id}/status`, null, { status });
  }
}
