import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Candidato, Vaga, Entrevista, DashboardKpis, StatusCandidato } from '../models/models';

const API = 'http://localhost:8080/api';

@Injectable({ providedIn: 'root' })
export class ApiService {

  constructor(private http: HttpClient) {}

  // ── Dashboard ─────────────────────────────────────────────
  getDashboardKpis(): Observable<DashboardKpis> {
    return this.http.get<DashboardKpis>(`${API}/dashboard/kpis`);
  }

  // ── Candidatos ────────────────────────────────────────────
  getCandidatos(): Observable<Candidato[]> {
    return this.http.get<Candidato[]>(`${API}/candidatos`);
  }

  getCandidato(id: number): Observable<Candidato> {
    return this.http.get<Candidato>(`${API}/candidatos/${id}`);
  }

  createCandidato(c: Candidato): Observable<Candidato> {
    return this.http.post<Candidato>(`${API}/candidatos`, c);
  }

  updateCandidato(id: number, c: Candidato): Observable<Candidato> {
    return this.http.put<Candidato>(`${API}/candidatos/${id}`, c);
  }

  updateStatusCandidato(id: number, status: StatusCandidato): Observable<Candidato> {
    const params = new HttpParams().set('status', status);
    return this.http.patch<Candidato>(`${API}/candidatos/${id}/status`, null, { params });
  }

  deleteCandidato(id: number): Observable<void> {
    return this.http.delete<void>(`${API}/candidatos/${id}`);
  }

  searchCandidatos(nome: string): Observable<Candidato[]> {
    const params = new HttpParams().set('nome', nome);
    return this.http.get<Candidato[]>(`${API}/candidatos/buscar`, { params });
  }

  // ── Vagas ─────────────────────────────────────────────────
  getVagas(): Observable<Vaga[]> {
    return this.http.get<Vaga[]>(`${API}/vagas`);
  }

  getVagasAbertas(): Observable<Vaga[]> {
    return this.http.get<Vaga[]>(`${API}/vagas/abertas`);
  }

  getVaga(id: number): Observable<Vaga> {
    return this.http.get<Vaga>(`${API}/vagas/${id}`);
  }

  createVaga(v: Vaga): Observable<Vaga> {
    return this.http.post<Vaga>(`${API}/vagas`, v);
  }

  updateVaga(id: number, v: Vaga): Observable<Vaga> {
    return this.http.put<Vaga>(`${API}/vagas/${id}`, v);
  }

  deleteVaga(id: number): Observable<void> {
    return this.http.delete<void>(`${API}/vagas/${id}`);
  }

  // ── Entrevistas ───────────────────────────────────────────
  getEntrevistas(): Observable<Entrevista[]> {
    return this.http.get<Entrevista[]>(`${API}/entrevistas`);
  }

  createEntrevista(e: Entrevista): Observable<Entrevista> {
    return this.http.post<Entrevista>(`${API}/entrevistas`, e);
  }

  updateEntrevista(id: number, e: Entrevista): Observable<Entrevista> {
    return this.http.put<Entrevista>(`${API}/entrevistas/${id}`, e);
  }
}
