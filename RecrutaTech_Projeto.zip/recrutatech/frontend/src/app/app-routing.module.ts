import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';
import { LoginComponent } from './pages/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { VagasComponent } from './pages/vagas/vagas.component';
import { CandidatosComponent } from './pages/candidatos/candidatos.component';
import { EntrevistasComponent } from './pages/entrevistas/entrevistas.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'vagas', component: VagasComponent, canActivate: [AuthGuard] },
  { path: 'candidatos', component: CandidatosComponent, canActivate: [AuthGuard] },
  { path: 'entrevistas', component: EntrevistasComponent, canActivate: [AuthGuard] },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
