import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ApiService } from '../../services/api.service';
import { Vaga } from '../../models/models';

@Component({
  selector: 'app-vagas',
  templateUrl: './vagas.component.html',
  styleUrls: ['./vagas.component.scss']
})
export class VagasComponent implements OnInit {

  vagas: Vaga[] = [];
  loading = false;
  showForm = false;
  editando: Vaga | null = null;

  form: FormGroup;
  displayedColumns = ['titulo', 'departamento', 'modalidade', 'status', 'acoes'];

  modalidades = ['PRESENCIAL', 'HIBRIDO', 'REMOTO'];
  statuses    = ['ABERTA', 'EM_SELECAO', 'ENCERRADA', 'PAUSADA'];

  constructor(
    private api: ApiService,
    private fb: FormBuilder,
    private snack: MatSnackBar
  ) {
    this.form = this.fb.group({
      titulo:      ['', Validators.required],
      descricao:   [''],
      departamento:[''],
      localizacao: [''],
      modalidade:  ['HIBRIDO', Validators.required],
      status:      ['ABERTA']
    });
  }

  ngOnInit(): void { this.carregar(); }

  carregar(): void {
    this.loading = true;
    this.api.getVagas().subscribe({
      next: v => { this.vagas = v; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  abrir(vaga?: Vaga): void {
    this.editando = vaga || null;
    this.form.reset(vaga ? vaga : { modalidade: 'HIBRIDO', status: 'ABERTA' });
    this.showForm = true;
  }

  fechar(): void { this.showForm = false; this.editando = null; }

  salvar(): void {
    if (this.form.invalid) return;
    const dados: Vaga = this.form.value;

    if (this.editando?.id) {
      this.api.updateVaga(this.editando.id, dados).subscribe({
        next: () => { this.snack.open('Vaga atualizada!', '', { duration: 2500 }); this.fechar(); this.carregar(); }
      });
    } else {
      this.api.createVaga(dados).subscribe({
        next: () => { this.snack.open('Vaga criada!', '', { duration: 2500 }); this.fechar(); this.carregar(); }
      });
    }
  }

  deletar(id: number): void {
    if (!confirm('Remover vaga?')) return;
    this.api.deleteVaga(id).subscribe({ next: () => { this.snack.open('Removida!', '', { duration: 2000 }); this.carregar(); } });
  }
}
