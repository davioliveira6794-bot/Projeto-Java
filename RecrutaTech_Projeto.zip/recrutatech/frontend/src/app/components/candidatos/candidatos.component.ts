import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ApiService } from '../../services/api.service';
import { Candidato, StatusCandidato } from '../../models/models';

@Component({
  selector: 'app-candidatos',
  templateUrl: './candidatos.component.html',
  styleUrls: ['./candidatos.component.scss']
})
export class CandidatosComponent implements OnInit {

  candidatos: Candidato[] = [];
  loading = false;
  showForm = false;
  editando: Candidato | null = null;

  form: FormGroup;
  displayedColumns = ['nome', 'cargo', 'score', 'status', 'acoes'];

  statuses: StatusCandidato[] = [
    'INSCRITO', 'TRIAGEM_IA', 'ENTREVISTA', 'TECNICO', 'OFERTA', 'APROVADO', 'REPROVADO'
  ];

  constructor(
    private api: ApiService,
    private fb: FormBuilder,
    private snack: MatSnackBar
  ) {
    this.form = this.fb.group({
      nome:       ['', [Validators.required, Validators.minLength(3)]],
      email:      ['', [Validators.required, Validators.email]],
      telefone:   [''],
      cargoAtual: [''],
      resumo:     [''],
      status:     ['INSCRITO']
    });
  }

  ngOnInit(): void {
    this.carregarCandidatos();
  }

  carregarCandidatos(): void {
    this.loading = true;
    this.api.getCandidatos().subscribe({
      next: (data) => { this.candidatos = data; this.loading = false; },
      error: () => { this.loading = false; this.snack.open('Erro ao carregar candidatos', 'OK', { duration: 3000 }); }
    });
  }

  abrirFormulario(candidato?: Candidato): void {
    this.editando = candidato || null;
    if (candidato) this.form.patchValue(candidato);
    else this.form.reset({ status: 'INSCRITO' });
    this.showForm = true;
  }

  fecharFormulario(): void {
    this.showForm = false;
    this.editando = null;
    this.form.reset();
  }

  salvar(): void {
    if (this.form.invalid) return;

    const dados: Candidato = this.form.value;

    if (this.editando?.id) {
      this.api.updateCandidato(this.editando.id, dados).subscribe({
        next: () => { this.snack.open('Candidato atualizado!', '', { duration: 2500 }); this.fecharFormulario(); this.carregarCandidatos(); },
        error: () => this.snack.open('Erro ao atualizar', 'OK', { duration: 3000 })
      });
    } else {
      this.api.createCandidato(dados).subscribe({
        next: () => { this.snack.open('Candidato criado!', '', { duration: 2500 }); this.fecharFormulario(); this.carregarCandidatos(); },
        error: () => this.snack.open('Erro ao criar candidato', 'OK', { duration: 3000 })
      });
    }
  }

  deletar(id: number): void {
    if (!confirm('Remover candidato?')) return;
    this.api.deleteCandidato(id).subscribe({
      next: () => { this.snack.open('Removido!', '', { duration: 2000 }); this.carregarCandidatos(); },
      error: () => this.snack.open('Erro ao remover', 'OK', { duration: 3000 })
    });
  }

  getScoreColor(score: number): string {
    if (score >= 80) return 'accent';
    if (score >= 50) return 'primary';
    return 'warn';
  }
}
