import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Entrevista } from '../../models/models';

@Component({
  selector: 'app-entrevistas',
  templateUrl: './entrevistas.component.html',
  styleUrls: ['./entrevistas.component.scss']
})
export class EntrevistasComponent implements OnInit {
  entrevistas: Entrevista[] = [];
  loading = false;
  displayedColumns = ['candidato', 'vaga', 'dataHora', 'tipo', 'status'];

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.loading = true;
    this.api.getEntrevistas().subscribe({
      next: e => { this.entrevistas = e; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }
}
