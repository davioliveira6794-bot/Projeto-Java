import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { DashboardKpis } from '../../models/models';
import { ChartConfiguration, ChartData } from 'chart.js';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  kpis: DashboardKpis | null = null;
  loading = true;

  // Dados do funil para o gráfico de barras
  funilChartData: ChartData<'bar'> = {
    labels: ['Inscritos', 'Triagem IA', 'Entrevista', 'Técnico', 'Oferta'],
    datasets: [{
      label: 'Candidatos',
      data: [320, 140, 80, 42, 18],
      backgroundColor: ['#5c6bc0', '#7986cb', '#9fa8da', '#3949ab', '#1a237e'],
      borderRadius: 6
    }]
  };

  funilChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: { y: { beginAtZero: true } }
  };

  // Gráfico de sourcing (pizza)
  sourcingChartData: ChartData<'doughnut'> = {
    labels: ['LinkedIn', 'Indicações', 'Site Próprio', 'Feiras', 'Outros'],
    datasets: [{
      data: [32, 25, 18, 10, 7],
      backgroundColor: ['#1a237e', '#5c6bc0', '#7986cb', '#9fa8da', '#c5cae9']
    }]
  };

  sourcingChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    plugins: {
      legend: { position: 'right', labels: { font: { size: 12 } } }
    }
  };

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.api.getDashboardKpis().subscribe({
      next: (data) => {
        this.kpis = data;
        this.atualizarFunilChart(data);
        this.loading = false;
      },
      error: () => {
        // Fallback com dados simulados
        this.kpis = this.getDadosSimulados();
        this.loading = false;
      }
    });
  }

  private atualizarFunilChart(kpis: DashboardKpis): void {
    if (!kpis.funil) return;
    const funil = kpis.funil;
    this.funilChartData = {
      ...this.funilChartData,
      datasets: [{
        ...this.funilChartData.datasets[0],
        data: [
          funil['INSCRITO'] || 0,
          funil['TRIAGEM_IA'] || 0,
          funil['ENTREVISTA'] || 0,
          funil['TECNICO'] || 0,
          funil['OFERTA'] || 0
        ]
      }]
    };
  }

  private getDadosSimulados(): DashboardKpis {
    return {
      totalCandidatos: 47,
      vagasAbertas: 12,
      diasMediosContratacao: 5,
      reducaoCusto: 30,
      taxaRetencao: 80,
      satisfacaoCandidatos: 92,
      funil: {
        INSCRITO: 320, TRIAGEM_IA: 140, ENTREVISTA: 80,
        TECNICO: 42, OFERTA: 18, APROVADO: 10, REPROVADO: 15
      },
      proximasEntrevistas: []
    };
  }
}
