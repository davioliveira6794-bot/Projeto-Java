import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  menuItems = [
    { icon: 'dashboard',  label: 'Dashboard',   route: '/dashboard' },
    { icon: 'work',       label: 'Vagas',        route: '/vagas' },
    { icon: 'people',     label: 'Candidatos',   route: '/candidatos' },
    { icon: 'event',      label: 'Entrevistas',  route: '/entrevistas' },
  ];

  constructor(public auth: AuthService, public router: Router) {}
  logout() { this.auth.logout(); }
}
