// ============================================================
// Models — RecrutaTech Frontend
// ============================================================

export type StatusCandidato =
  | 'INSCRITO' | 'TRIAGEM_IA' | 'ENTREVISTA' | 'TECNICO' | 'OFERTA'
  | 'APROVADO' | 'REPROVADO';

export type StatusVaga = 'ABERTA' | 'EM_SELECAO' | 'ENCERRADA' | 'PAUSADA';
export type ModalidadeVaga = 'PRESENCIAL' | 'HIBRIDO' | 'REMOTO';
export type StatusEntrevista = 'AGENDADA' | 'REALIZADA' | 'CANCELADA' | 'REAGENDADA';
export type TipoEntrevista = 'TRIAGEM' | 'TECNICA' | 'COMPORTAMENTAL' | 'FINAL';

export interface Candidato {
  id?: number;
  nome: string;
  email: string;
  telefone?: string;
  cargoAtual?: string;
  resumo?: string;
  scoreIa?: number;
  status: StatusCandidato;
  criadoEm?: string;
  atualizadoEm?: string;
  vaga?: Vaga;
}

export interface Vaga {
  id?: number;
  titulo: string;
  descricao?: string;
  departamento?: string;
  localizacao?: string;
  modalidade: ModalidadeVaga;
  status: StatusVaga;
  dataAbertura?: string;
  dataFechamento?: string;
  criadoEm?: string;
  candidatos?: Candidato[];
}

export interface Entrevista {
  id?: number;
  candidato: Candidato;
  vaga: Vaga;
  dataHora: string;
  tipo: TipoEntrevista;
  status: StatusEntrevista;
  observacoes?: string;
  linkReuniao?: string;
  criadoEm?: string;
}

export interface DashboardKpis {
  totalCandidatos: number;
  vagasAbertas: number;
  diasMediosContratacao: number;
  reducaoCusto: number;
  taxaRetencao: number;
  satisfacaoCandidatos: number;
  funil: Record<StatusCandidato, number>;
  proximasEntrevistas: Entrevista[];
}
